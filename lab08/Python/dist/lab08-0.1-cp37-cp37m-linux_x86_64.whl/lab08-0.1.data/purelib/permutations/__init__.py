# import ctypes as c
#
# lib_path = c.os.path.join(c.os.path.dirname(__file__), 'libeay32.dll')
# lib = c.CDLL(lib_path)
